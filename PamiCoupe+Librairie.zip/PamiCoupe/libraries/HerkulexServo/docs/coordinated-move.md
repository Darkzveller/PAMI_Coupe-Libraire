# Coordinated move

This example moves two servos back to neutral over a period of 1120
milliseconds.

[include, lang:"C++"](../examples/CoordinatedMove/CoordinatedMove.ino)
